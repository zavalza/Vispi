#include <iostream>
#include <string>
#include <math.h>
// llenar con las librer'ias necesarias para openCV
